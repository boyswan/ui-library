import React, { useState } from 'react';

function Test() {
    const [number, setNumber] = useState(5);
    
    return (
        <div>Test Component</div>
    )
}

export default Test;