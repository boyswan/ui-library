import Countdown from './components/Countdown';
import Test from './components/Test';

module.exports = {
    Countdown,
    Test
}